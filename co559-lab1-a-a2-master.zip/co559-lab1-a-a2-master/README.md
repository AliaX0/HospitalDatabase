# CO559 LAB1 Group A - Assessment 2
## About
This repository contains the combined work of:
- Dominykas Sliuzas (ds725)
- Ethan O'Donnell (ejpo2)
- Lia Wilkinson (lw517)
- Rahul Mistry (rm271)

Our task is to design a Patient Facing information system for a Doctors Surgery.

## How to use

### Download GIT-SCM
Make sure you have git installed on your system.

You want to make sure you have git available from the command line if using VS Code.

**Windows:**
https://git-scm.com/download/win

*Make sure that you add git to your path during the installation process*

**MacOS:** Use system installed git *(not reccomended)* OR if using Homebrew download the latest version of git using:
```
brew install git
```

### Clone the Repository
*NB: Please avoid cloning the repository into anything like Dropbox or Google Drive as the metadata for these systems will be pushed into Source Control*

Now you need to downlaod the repository onto your computer.

You can do this over two protocols: ***HTTPS*** and ***SSH***

HTTPS is the simplest, but you will need to enter a username and password everytime you push code up to the central repository.

SSH doesn't have this limitation but requires you to set up a public/private key to use for authentication instead.

#### Cloning using HTTPS
If you chose HTTPS then simply navigate to the directory you store your projects in terminal/CMD:
```
git clone https://git.cs.kent.ac.uk/ejpo2/co559-lab1-a-a2.git
```

#### Cloning using SSH
Create a Public/Private Key pair using the following instructions if you don't have one already:

https://docs.gitlab.com/ee/ssh/#generate-an-ssh-key-pair

Add the public key to your GitLab profile on **this** server (https://git.cs.kent.ac.uk):

https://docs.gitlab.com/ee/ssh/#add-an-ssh-key-to-your-gitlab-account

Navigate to your project directory in terminal/CMD and run:
```
git clone git@git.cs.kent.ac.uk:ejpo2/co559-lab1-a-a2.git
```

### Open in IntelliJ
Opening the Repo in IntelliJ is pretty simple.
1. Open IntelliJ
2. Select open on the project page and navigate to where the repo was cloned to
3. Wait a few seconds as the project opens for the first time and click import porject on the bottom right when the pop up appears.

### Open in VS Code
VS Code is a bit trickier, mainly because you have to point VS Code to your JDK Install
1. Install the follwoing extension Kit for Java: https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack
2. Set the "jdk.home" setting in your VS Code settings to your JDK install path in your vscode settings.json. Mine for eample is: "java.home": "/opt/homebrew/opt/openjdk"
3. Open the folder containing the repo in VS Code as a workspace
